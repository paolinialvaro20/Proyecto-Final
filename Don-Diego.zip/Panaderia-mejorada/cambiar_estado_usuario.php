<?php
require_once __DIR__ . "/seguridad.php";
require_once "conexion.php";
require_once "registrar_auditoria.php";

// Verificar que haya un usuario logueado
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

require_once "permisos.php";
exigirPermiso($conexion, $_SESSION["id_usuario"], "usuarios.cambiar_estado");

$mensaje = "";
$error = "";


 // Procesar cambio de estado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST["id"] ?? "";
    $activo = $_POST["activo"] ?? "";

    if ($id === "" || !ctype_digit((string)$id) || (int)$id <= 0) {
        $error = "Usuario no válido.";

    } elseif ($activo !== "0" && $activo !== "1") {
        $error = "Estado no válido.";

    } else {
        try {
            // Obtener los datos actuales del usuario
            $sql = "SELECT id, usuario, activo
                    FROM usuario
                    WHERE id = :id";

            $stmt = $conexion->prepare($sql);
            $stmt->execute([":id" => $id]);

            $usuarioSeleccionado = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$usuarioSeleccionado) {
                $error = "El usuario seleccionado no existe.";

            } elseif ((string)$usuarioSeleccionado["activo"] === $activo) {
                $error = "El usuario ya tiene ese estado.";

            } elseif (!puedeTocarUsuario($conexion, $_SESSION["id_usuario"], (int)$usuarioSeleccionado["id"])) {
                $error = "No tenés permiso para modificar a un administrador.";

            } elseif ($activo === "0" && (int)$usuarioSeleccionado["id"] === (int)$_SESSION["id_usuario"]) {
                $error = "No podés desactivar tu propio usuario.";

            } elseif (
                $activo === "0"
                && esAdministradorActivo($conexion, (int)$usuarioSeleccionado["id"])
                && otrosAdministradoresActivos($conexion, (int)$usuarioSeleccionado["id"]) === 0
            ) {
                $error = "No se puede desactivar al último administrador activo.";

            } else {
                // Determinar los estados anterior y nuevo
                $estadoAnterior = (int)$usuarioSeleccionado["activo"] === 1
                    ? "Activo"
                    : "Inactivo";

                $estadoNuevo = $activo === "1"
                    ? "Activo"
                    : "Inactivo";

                $accion = $activo === "1"
                    ? "ACTIVAR"
                    : "DESACTIVAR";

                try {
                    // Iniciar transacción
                    $conexion->beginTransaction();

                    // Actualizar el estado
                    $sql = "UPDATE usuario
                            SET activo = :activo
                            WHERE id = :id";

                    $stmt = $conexion->prepare($sql);
                    $stmt->execute([
                        ":activo" => $activo,
                        ":id" => $id
                    ]);

                    // Registrar el movimiento de auditoría
                    registrarAuditoria(
                        $conexion,
                        $_SESSION["id_usuario"],
                        $accion,
                        "Usuario",
                        $usuarioSeleccionado["id"],
                        "Se " .
                            ($activo === "1" ? "activó" : "desactivó") .
                            " el usuario " .
                            $usuarioSeleccionado["usuario"],
                        "Estado: " . $estadoAnterior,
                        "Estado: " . $estadoNuevo
                    );

                    // Confirmar actualización y auditoría
                    $conexion->commit();

                    $mensaje = $activo === "1"
                        ? "Usuario activado correctamente."
                        : "Usuario desactivado correctamente.";

                } catch (Exception $e) {
                    if ($conexion->inTransaction()) {
                        $conexion->rollBack();
                    }

                    $error = "Error al cambiar el estado del usuario.";
                }
            }

        } catch (PDOException $e) {
            $error = "Error al consultar el usuario.";
        }
    }
}


// Obtener todos los usuarios
try {
    $sql = "SELECT id, usuario, activo FROM usuario ORDER BY id";
    $stmt = $conexion->query($sql);
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $usuarios = [];
    $error = "No se pudieron cargar los usuarios.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar estado de usuario</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap-5.3.8/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <!-- Estilos propios -->
    <link rel="stylesheet" href="css/estilo.css">
    <link rel="stylesheet" href="fondo-sistema.css?v=1">
    <link rel="stylesheet" href="tema-don-diego.css?v=2">
<link rel="stylesheet" href="imagenes/bootstrap-icons-1.13.1/bootstrap-icons.min.css">
</head>
<body>
    <?php require_once "menu.php"; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-6">
                <div class="card shadow">

                    <!-- Encabezado -->
                    <div class="card-header bg-dark text-white text-center">
                        <h4 class="mb-0"><i class="bi bi-person-check-fill"></i> Cambiar estado de usuario</h4>
                    </div>
                    <div class="card-body">

                        <!-- Mensaje de éxito -->
                        <?php if ($mensaje !== ""): ?>
                            <div class="alert alert-success alert-dismissible fade show"
                                 role="alert">
                                <i class="bi bi-check-circle-fill"></i>
                                <?= htmlspecialchars($mensaje) ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <!-- Mensaje de error -->
                        <?php if ($error !== ""): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="bi bi-exclamation-triangle-fill"></i>
                                <?= htmlspecialchars($error) ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <!-- Información -->
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle-fill"></i>
                            Seleccione un usuario y luego indique si desea
                            activarlo o desactivarlo.
                        </div>

                        <?php if (count($usuarios) > 0): ?>
                            <form method="POST">
<?= csrfCampo() ?>

                                <!-- Usuario -->
                                <div class="mb-3">
                                    <label for="id" class="form-label"><i class="bi bi-person-fill"></i> Seleccionar usuario</label>
                                    <select name="id" id="id" class="form-select" required>
                                        <option value="">Seleccionar usuario</option>
                                        
                                        <?php foreach ($usuarios as $usuario): ?>
                                            <option value="<?= htmlspecialchars($usuario["id"]) ?>">
                                                <?= htmlspecialchars($usuario["usuario"]) ?>
                                                -
                                                <?php if ($usuario["activo"] == 1): ?>
                                                    Activo
                                                <?php else: ?>
                                                    Inactivo
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; ?>

                                    </select>
                                </div>

                                <!-- Estado -->
                                <div class="mb-4">
                                    <label for="activo" class="form-label"><i class="bi bi-toggle-on"></i> Nuevo estado</label>
                                    <select name="activo" id="activo" class="form-select" required>
                                        <option value="">Seleccionar estado</option>
                                        <option value="1">Activo</option>
                                        <option value="0">Inactivo</option>
                                    </select>
                                </div>

                                <!-- Botón -->
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary"><i class="bi bi-arrow-repeat"></i> Cambiar estado</button>
                                </div>
                            </form>

                        <?php else: ?>
                            <div class="alert alert-secondary text-center">
                                <i class="bi bi-people-fill"></i> No hay usuarios registrados.
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <!-- JavaScript de Bootstrap 5.3.8 -->
    <script src="js/bootstrap-5.3.8/js/bootstrap.bundle.min.js"></script>
</body>
